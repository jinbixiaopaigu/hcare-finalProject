#! /usr/bin/env python
# -*- coding: UTF-8 -*-
import traceback

from .CustomException import CustomException

ERR_CODE_CONFIGERR = "001"  # 配置错误

ERR_CODE_NOT_AUTHED = "002"  # 验签失败

ERR_CODE_PARAM_MUST_NOT_EMPTY = "003"  # 参数不能为空

ERR_CODE_PARAM_REQ_NOT_MATCH = "004"  # 参数类型与指定不符

ERR_CODE_UPLOAD_PATH_INVALID = "005"  # 非法上传路径

ERR_CODE_PARAM_LENGTH_EXCEEDED = "006"  # 参数超长

ERR_CODE_MAX_KEYS_INVALID = "007"  # 非法最大分页数量

ERR_CODE_INTERNAL = "999"  # 内部错误

ERR_CODE_CLOUD_ERROR = "009"  # 组件返回异常


def get_err_msg(exception: object):
    """
    获取错误信息
    :param exception:
    :return:
    """
    if type(exception) == CustomException:
        return "错误码:%s 错误信息:%s 堆栈:%s" % (exception.errorCode, exception.message, traceback.format_exc())
    else:
        return "错误码:%s 错误信息:%s 堆栈:%s" % (
            ERR_CODE_INTERNAL, exception.message if hasattr(exception, "message") else str(exception),
            traceback.format_exc())
