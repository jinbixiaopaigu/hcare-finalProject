#! /usr/bin/env python
# -*- coding: UTF-8 -*-


class CustomException(Exception):
    """
    自定义异常
    """

    def __init__(self, errorcode, msg):
        Exception.__init__(self)
        self.message = msg
        self.errorCode = errorcode

    def __str__(self):
        return "Code:%s Message:%s" % (self.errorCode, self.message)
