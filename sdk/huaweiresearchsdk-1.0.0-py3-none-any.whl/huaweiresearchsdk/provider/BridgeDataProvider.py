#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ..config import RequestConfig
from ..config import BridgeConfig, HttpClientConfig
from ..model import GetFileRequest, ListObjectRequest, BatchGetFileRequest
from ..model.table import SearchTableDataRequest
from ..model.result import ListObjectResponse
from ..provider import ApiClientProvider
from ..service import HiResearchDataService


class BridgeDataProvider(object):
    def __init__(self, bridgeconfig: BridgeConfig, httpclientconfig: HttpClientConfig,
                 apiclientprovider: ApiClientProvider,requestconfig: RequestConfig = None):
        self.__bridgeConfig = bridgeconfig
        self.__requestconfig = requestconfig
        self.__hiresearchdataservice = HiResearchDataService(bridgeconfig, httpclientconfig, requestconfig, apiclientprovider)

    def list_projects(self) -> any:
        """
        创建研究数据表
        :param req:
        :return:
        """
        return self.__hiresearchdataservice.list_projects()

    def query_table_data(self, req: SearchTableDataRequest, callback: any):
        """
        查询研究数据表数据
        :param req:
        :param callback: 回调函数，用于处理数据行
        :return:
        """
        return self.__hiresearchdataservice.query_table_data(req, callback)

    def batch_download_file(self, req: BatchGetFileRequest) -> any:
        """
        批量下载文件
        :param req:
        :return:
        """
        return self.__hiresearchdataservice.batch_download_file(req)

    def list_objects(self, req: ListObjectRequest) -> ListObjectResponse:
        """
        列举指定目录下的文件、目录列表
        本API为分页API，单次返回最大1000条数据，如果超出一千条，API返回参数会包含next_marker作为分页参数，再次调用本API并传入marker即可
        :param req:
        :return:
        """
        return self.__hiresearchdataservice.list_objects(req)

