#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ..utilities import Utils


class RequestConfig(object):

    def __init__(self, headers: dict = None):
        self.__headers = headers

    def get_headers(self):
        """
        获取headers
        :return:
        """
        return self.__headers

