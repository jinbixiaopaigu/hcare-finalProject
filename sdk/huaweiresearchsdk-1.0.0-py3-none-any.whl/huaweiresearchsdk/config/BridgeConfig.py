#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ..utilities import Utils


class BridgeConfig(object):
    __DEFAULT_VERSION = 1.0

    URL_PROJECT_LIST = "researchservices/v1/user/projects"
    URL_SEARCH_TABLE_DATA = "researchservices/v1/tables/scroll"
    URL_FILE_LIST = "researchservices/v1/sdkfiles"
    URL_FILE_DOWNLOAD = "researchservices/v1/downloads/urls"
    URL_CLEAN_SCROLL = "researchservices/v1/tables/clearscroll"

    def __init__(self, env: str = "product", access_key: str = "", access_secret: str = ""):
        Utils.assert_not_none(env, "HUAWEI Research后台接口地址")
        Utils.assert_not_none(access_key, "AccessKey不能为空")
        Utils.assert_not_none(access_secret, "AccessSecret不能为空")

        self.set_env(env)
        self.__access_key = access_key
        self.__access_secret = access_secret

    def get_useragent(self):
        """
        获取useragent
        :return:
        """
        return "(python) BridgeSDK/%s" % self.__DEFAULT_VERSION

    def get_baseurl(self):
        """
        获取baseurl
        :return:
        """
        return self.__base_url

    def get_access_key(self):
        """
        获取access_key
        :return:
        """
        return self.__access_key

    def get_access_secret(self):
        """
        获取access_secret
        :return:
        """
        return self.__access_secret

    def set_env(self, env):
        """
        设置环境
        :param env:
        :return:
        """
        if env == "local":
            self.__base_url = "http://localhost:8096/thirdparty"
        if env == "alpha":
            self.__base_url = "http://10.32.229.23:8080/thirdpartyzws"
        elif env == "beta":
            self.__base_url = "http://10.32.229.5:8080/thirdparty"
        elif env == "product":
            self.__base_url = "https://research-drcn.things.dbankcloud.cn/thirdparty"

