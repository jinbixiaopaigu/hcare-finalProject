#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from requests.adapters import HTTPAdapter


class HttpClientConfig(object):
    """
    http客户端配置
    """

    def __init__(self, connect_timeout: int = 30, read_timeout: int = 30, retry_on_fail: bool = False):
        """
        初始化
        :param connect_timeout: 连接超时，默认30s
        :param read_timeout: 读超时，默认30s
        :param retry_on_fail: 失败重试，默认不重试
        """
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self.retry_on_fail = retry_on_fail

    def get_connect_timeout(self):
        """
        获取连接超时
        :return:
        """
        return self.connect_timeout

    def set_connect_timeout(self, connect_timeout: int):
        """
        设置连接超时
        :param connect_timeout:
        :return:
        """
        self.connect_timeout = connect_timeout

    def get_read_timeout(self):
        """
        获取读超时
        :return:
        """
        return self.read_timeout

    def set_read_timeout(self, read_timeout: int):
        """
        设置读超时
        :param read_timeout:
        :return:
        """
        self.read_timeout = read_timeout

    def is_retry_on_fail(self):
        """
        获取是否重试
        :return:
        """
        return self.retry_on_fail

    def set_retry_on_fail(self, retry_on_fail: bool):
        """
        设置是否重试
        :param retry_on_fail:
        :return:
        """
        self.retry_on_fail = retry_on_fail

    def get_httpadapter(self):
        """
        获取重试配置器
        :return:
        """
        if self.retry_on_fail is not True:
            return None

        default_retry_times = 5
        return HTTPAdapter(max_retries=default_retry_times)
