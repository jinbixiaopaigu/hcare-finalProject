#! /usr/bin/env python
# -*- coding: UTF-8 -*-


class ListProjectsResult(object):

    def __init__(self, projects: list):

        """
        项目信息列表
        :param projects:
        """

        self.projects = projects

    def get_objects(self):
        """
        获取项目列表
        :return:
        """
        return self.projects
