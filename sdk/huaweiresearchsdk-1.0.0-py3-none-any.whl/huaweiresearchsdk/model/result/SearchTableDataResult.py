#! /usr/bin/env python
# -*- coding: UTF-8 -*-


class SearchTableDataResult(object):
    def __init__(self, rows: list, total_cnt: int, scrollid: str, scrollid_valid_until_in_millis: int):
        """
        create search result holder
        :param rows: 查询返回的数据行
        :param total_cnt: 命中搜索条件的行数数量
        :param scrollid: 用于查询下一页的scrollid
        :param scrollid_valid_until_in_millis: scrollid的有效截止时间
        """
        self.rows = rows
        self.totalCnt = total_cnt
        self.scrollId = scrollid
        self.scrollIdValidUntilInMillis = scrollid_valid_until_in_millis
