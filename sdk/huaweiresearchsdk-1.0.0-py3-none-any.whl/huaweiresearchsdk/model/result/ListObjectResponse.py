#! /usr/bin/env python
# -*- coding: UTF-8 -*-


class ListObjectResponse(object):
    """
    列举对象列表的响应
    """

    def __init__(self, objects: list, next_marker: str, is_truncated: bool = False):
        """
        对象
        :param objects:
        :param next_marker:
        :param is_truncated: 表明是否本次返回的ListBucketResult结果列表被截断。“true”表示本次没有返回全部结果；“false”表示本次已经返回了全部结果。
        """
        self.__objects = objects
        self.__next_marker = next_marker
        self.__is_truncated = is_truncated

    def get_objects(self):
        """
        获取对象列表
        :return:
        """
        return self.__objects

    def get_next_marker(self):
        """
        获取下页标识，如果为空，代表已经全部获取完了
        :return:
        """
        return self.__next_marker

    def get_is_truncated(self):
        """
        获取是否还有数据没有返回的标识
        :return:
        """
        return self.__is_truncated
