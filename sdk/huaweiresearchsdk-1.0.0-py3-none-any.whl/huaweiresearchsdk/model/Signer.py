#! /usr/bin/env python
# -*- coding: UTF-8 -*-

import sys
from datetime import datetime

from ..model import AuthRequest
from ..utilities import SignHelper, Consts


class Signer:
    def __init__(self, access_key: str = "", access_secret: str = ""):
        self.__access_key = access_key
        self.__access_secret = access_secret

    def sign(self, request: AuthRequest):
        """
        SignRequest set Authorization header
        :param request:
        :return:
        """
        if sys.version_info.major == 3 and isinstance(request.body, str):
            request.body = request.body.encode('utf-8')
        header_time = SignHelper.find_header(request, Consts.RESEARCH_SDK_TIME)
        if header_time is None:
            new_time = datetime.utcnow()
            request.headers[Consts.RESEARCH_SDK_TIME] = datetime.strftime(new_time, Consts.BASIC_DATE_FORMAT)
        else:
            new_time = datetime.strptime(header_time, Consts.BASIC_DATE_FORMAT)

        have_host = False
        for key in request.headers:
            if key.lower() == 'host':
                have_host = True
                break
        if not have_host:
            request.headers[Consts.HEADER_HOST] = request.host
        signed_headers = SignHelper.build_signed_headers(request)
        canonical_request = SignHelper.build_canonical_request(request, signed_headers)
        string_sign = SignHelper.string_sign(canonical_request, new_time)
        signature = SignHelper.build_signature(string_sign, self.__access_secret)
        auth_value = SignHelper.build_authHeader_Value(signature, self.__access_key, signed_headers)
        request.headers[Consts.RESEARCH_AUTHORIZATION] = auth_value
        request.headers["content-length"] = str(len(request.body))
        request.headers[Consts.RESEARCH_SDK_ALG] = Consts.ALGORITHM_256
        query_string = SignHelper.build_canonical_query_string(request)
        if query_string != "":
            request.uri = request.uri + "?" + query_string
