#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from .FilterLogicType import FilterLogicType
from .FilterOperatorType import FilterOperatorType


class FilterCondition(object):
    """
    create filter condition
    """

    def __init__(self, name: str, operator: FilterOperatorType, value: any = None, sub_conditions: list = None,
                 logic: FilterLogicType = FilterLogicType.AND):
        """
        create an filter condition
        :param name: field name
        :param operator: filter operator, see enmu FilterOperatorType
        :param value: field value
        :param sub_conditions: nested filter conditions
        :param logic: filter logic, see enmu FilterLogicType. default "AND"
        """
        self.operator = operator

        self.name = name

        if operator == FilterOperatorType.CONTAINS:
            self.value = "*" + value + "*"
        else:
            self.value = value

        self.subConditions = sub_conditions
        self.logic = logic
