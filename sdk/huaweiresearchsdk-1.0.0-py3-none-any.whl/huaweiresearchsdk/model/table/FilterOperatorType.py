#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class FilterOperatorType(Enum):
    """
    filter operator enum definition
    """
    EQUALS = "equals"  # 等于
    NOT_EQUALS = "not equals"  # 不等于
    CONTAINS = "contains"  # 包含
    GREATER_THAN = "greater than"  # 大于
    LESS_THAN = "less than"  # 小于
    GREATER_EQUALS = "greater equals"  # 大于等于
    LESS_EQUALS = "less equals"  # 小于等于
    EXISTS = "exists"  # 字段存在
    NOT_EXISTS = "not exists"  # 字段不存在
    IN = "in"  # 在列表中
    NOT_IN = "not in"  # 不在列表中
    DISTINCT = "distinct" # 去重

    def __init__(self, value):
        pass
