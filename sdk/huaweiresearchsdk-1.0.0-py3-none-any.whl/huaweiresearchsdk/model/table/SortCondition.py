#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from .SortType import SortType


class SortCondition(object):
    def __init__(self, name: str, type: SortType):
        """
        create an sort condition
        :param name: name of field to be sorted
        :param type: sort type
        """
        self.name = name
        self.type = type
