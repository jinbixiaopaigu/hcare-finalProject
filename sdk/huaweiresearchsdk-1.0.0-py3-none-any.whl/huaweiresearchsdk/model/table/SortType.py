#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class SortType(Enum):
    """
    sort type enum definition
    """
    ASC = "asc"
    DESC = "desc"

    def __init__(self, value):
        pass
