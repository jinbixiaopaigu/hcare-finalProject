#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ...exceptions import CustomException, ErrorCodes
from ...utilities import Utils


class TableField(object):
    """
    研究数据表字段
    """
    TYPE_BOOLEAN = "Boolean"  # 布尔类型
    TYPE_BIGINT = "Integer"  # 整形
    TYPE_DOUBLE = "Double"  # 浮点类型
    TYPE_STRING = "String"  # 字符串类型（不能存储超过8K的内容）
    CONST_TYPE_ARRAY = [TYPE_BOOLEAN, TYPE_BIGINT, TYPE_DOUBLE, TYPE_STRING]

    def __init__(self, field_name: str, field_type: str, description: str):
        """
        构造器
        :param field_name:  名称
        :param field_type:  类型
        :param description:  描述
        """
        Utils.assert_not_none(field_name, "name")
        Utils.assert_not_none(field_type, "type")

        if self.CONST_TYPE_ARRAY.index(field_type) < 0:
            raise CustomException(ErrorCodes.ERR_CODE_CONFIGERR,
                                  "字段%s类型%s非法！" % (field_name, field_type))

        self.__name = field_name
        self.__type = field_type
        self.__description = description if description is not None else ""

    def get_name(self):
        return self.__name

    def get_type(self):
        return self.__type

    def get_description(self):
        return self.__description
