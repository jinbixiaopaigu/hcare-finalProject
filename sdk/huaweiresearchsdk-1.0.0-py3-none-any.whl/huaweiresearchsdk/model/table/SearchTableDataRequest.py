#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ...utilities import Utils


class SearchTableDataRequest(object):
    """
    表数据查询请求
    """

    def __init__(self, index_name: str, filters: list = None,
                 desired_size: int = None,
                 sorts: list = None, include_fields: list = None, exclude_fields: list = None,
                 giveup_when_more_than: int = None, project_id: str = None, scroll_id: str = None):
        """
        创建请求
        :param index_name: 表id
        :param cursor: 聚合查询使用的分页依据
        :param filters:  过滤器列表
        :param desired_size:  本次获取数据行数，不要超过5000
        :param sorts:  排序器列表
        :param include_fields: 需要包含的字段，不指定返回全部
        :param exclude_fields: 需要排除的字段，不指定不排除。请不要与include_filelds同时使用
        :param giveup_when_more_than: 当查询返回的结果条数大于指定条数时，放弃后续查询
        """

        Utils.assert_not_none(index_name, "index_name")

        self.indexName = index_name
        self.filters = filters
        self.sorts = sorts
        self.size = desired_size
        self.includeFields = include_fields
        self.excludeFields = exclude_fields
        self.giveUpWhenMoreThan = giveup_when_more_than
        self.project_id = project_id
        self.virtualScrollId = scroll_id
