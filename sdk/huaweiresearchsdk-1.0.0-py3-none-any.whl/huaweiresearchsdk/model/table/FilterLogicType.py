#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class FilterLogicType(Enum):
    """
    filter logic enum definition
    """
    AND = "and"
    OR = "or"

    def __init__(self, value):
        pass
