#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..exceptions import CustomException, ErrorCodes
from ..utilities import Utils


class BatchGetFileRequest(object):
    """
    获取文件对象请求
    """

    def __init__(self, filepaths: list, output_path: str, project_id: str = None):
        """
        初始化
        :param filepaths: 对象路径，必须是文件路径列表
        """
        Utils.assert_not_none(filepaths, "filepaths")
        Utils.assert_not_none(output_path, "output_path")

        file_path_list = []
        for path in filepaths:
            # validate special characters
            if path.find(":") >= 0 or path.find("\\") >= 0:
                raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "目的路径不能包含英文冒号与反斜杠！")

            # validate dest path
            trimed_destpath = path.strip()

            # remove first /
            if trimed_destpath[0] == "/":
                trimed_destpath = trimed_destpath[1:]

            # check whether there is an empty folder in the path
            parts = trimed_destpath.split("/")
            for idx, part in enumerate(parts, start=0):
                if idx == 0 or idx == len(parts):
                    continue
                if part.strip() == "":
                    raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "目的路径中包含空目录！")

            if trimed_destpath[len(trimed_destpath) - 1] == "/":
                raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "目的路径需要精确到文件名！")

            file_path_list.append(path)

        self.__filepaths = file_path_list
        self.__outputpath = output_path
        self.__project_id = project_id

    def get_file_paths(self):
        return self.__filepaths

    def get_output_path(self):
        return self.__outputpath

    def get_project_id(self):
        return self.__project_id
