#! /usr/bin/env python
# -*- coding: UTF-8 -*-
import json


class ObjectMeta(object):
    """
    file元数据
    """

    # 对象名称
    __name: str = ""
    # 是否为目录
    __is_folder: bool = False
    # 对象大小
    __size: int = 0

    def __init__(self, name, is_foldler, size):
        self.__name = name
        self.__is_folder = is_foldler
        self.__size = size

    def get_name(self):
        return self.__name

    def is_folder(self):
        return self.__is_folder

    def get_size(self):
        return self.__size

    def __str__(self) -> str:
        json_dict = {
            'name': self.__name,
            'isFolder': self.__is_folder,
            'size': self.__size
        }
        return json.dumps(json_dict)

    def __repr__(self) -> str:
        return self.__str__()

