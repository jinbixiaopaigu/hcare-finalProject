#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from enum import Enum


class HttpMethod(Enum):
    """
    http method
    """
    PUT = "PUT"
    GET = "GET"
    DELETE = "DELETE"
    POST = "POST"

    def __init__(self, value):
        pass
