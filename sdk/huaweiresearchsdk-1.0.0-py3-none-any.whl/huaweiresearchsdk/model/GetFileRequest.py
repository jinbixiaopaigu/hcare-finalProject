#! /usr/bin/env python
# -*- coding: UTF-8 -*-

from ..exceptions import CustomException, ErrorCodes
from ..utilities import Utils


class GetFileRequest(object):
    """
    获取文件对象请求
    """

    def __init__(self, filepath: str, output_path: str = None, project_id: str = None):
        """
        初始化
        :param filepath: 对象路径，必须是一个文件路径
        """
        Utils.assert_not_none(filepath, "filepath")

        index_num = filepath.find("obs://")
        # from copypath
        if index_num >= 0:
            trimed_destpath = filepath.strip()
            # remove obs://
            split_parts = trimed_destpath.split("/customuploads/")
            if len(split_parts) != 2:
                raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "目标路径不正确")

            trimed_destpath = split_parts[1]
        else:
            # validate special characters
            if filepath.find(":") >= 0 or filepath.find("\\") >= 0:
                raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "目的路径不能包含英文冒号与反斜杠！")

            # validate dest path
            trimed_destpath = filepath.strip()

            # remove first /
            if trimed_destpath[0] == "/":
                trimed_destpath = trimed_destpath[1:]

        # check whether there is an empty folder in the path
        parts = trimed_destpath.split("/")
        for idx, part in enumerate(parts, start=0):
            if idx == 0 or idx == len(parts):
                continue
            if part.strip() == "":
                raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "目的路径中包含空目录！")

        if trimed_destpath[len(trimed_destpath) - 1] == "/":
            raise CustomException(ErrorCodes.ERR_CODE_UPLOAD_PATH_INVALID, "目的路径需要精确到文件名！")

        target_filepath = filepath if(index_num >= 0) else trimed_destpath

        self.__filepath = target_filepath
        self.__outputpath = output_path
        self.__project_id = project_id

    def get_filepath(self):
        return self.__filepath

    def get_output_path(self):
        return self.__outputpath

    def get_project_id(self):
        return self.__project_id
