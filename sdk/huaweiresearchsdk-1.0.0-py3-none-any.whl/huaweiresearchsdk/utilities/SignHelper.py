#! /usr/bin/env python
# -*- coding: UTF-8 -*-

import sys
import hashlib
import hmac
import binascii
from datetime import datetime

from ..model import AuthRequest
from ..utilities import Consts

if sys.version_info.major < 3:
    from urllib import quote, unquote


    def hmacsha256(keyByte, message):
        return hmac.new(keyByte, message, digestmod=hashlib.sha256).digest()


    # Create a "String to Sign".
    def string_sign(canonical_request, time):
        bytes = HexEncodeSHA256Hash(canonical_request)
        return "%s\n%s\n%s" % (Consts.ALGORITHM_256, datetime.strftime(time, Consts.BASIC_DATE_FORMAT), bytes)

else:
    from urllib.parse import quote, unquote


    def hmacsha256(keyByte, message):
        return hmac.new(keyByte.encode('utf-8'), message.encode('utf-8'), digestmod=hashlib.sha256).digest()


    # Create a "String to Sign".
    def string_sign(canonical_request, time):
        bytes = HexEncodeSHA256Hash(canonical_request.encode('utf-8'))
        return "%s\n%s\n%s" % (Consts.ALGORITHM_256, datetime.strftime(time, Consts.BASIC_DATE_FORMAT), bytes)


def build_canonical_request(request: AuthRequest, signed_headers: []):
    """
    编码组装request请求体
    CanonicalRequest =
        HTTPRequestMethod + '\n' +
        CanonicalURI + '\n' +
        CanonicalQueryString + '\n' +
        CanonicalHeaders + '\n' +
        SignHeaders + '\n' +
        HexEncode(Hash(RequestPayload))
    :param request:
    :param signed_headers:
    :return:
    """
    canonical_headers = build_canonical_headers(request, signed_headers)
    hexencode = find_header(request, Consts.RESEARCH_SDK_CONTENT)
    if hexencode is None:
        hexencode = HexEncodeSHA256Hash(request.body)
    return "%s\n%s\n%s\n%s\n%s\n%s" % (request.method.upper(), build_canonical_uri(request), build_canonical_query_string(request),
                                       canonical_headers, ";".join(signed_headers), hexencode)


def build_canonical_query_string(request: AuthRequest):
    """
    编码组装请求参数，如果参数中有limit=xx&limit=xx1,则,号分隔的value值，则以list形式表示，即{'limit':['xx','xx1']}
    :param request: auth request
    :return:
    """
    keys = []
    for key in request.query:
        keys.append(key)
    keys.sort()
    a = []
    for key in keys:
        k = url_encode(key)
        value = request.query[key]
        if type(value) is list:
            value.sort()
            for v in value:
                kv = k + "=" + url_encode(str(v))
                a.append(kv)
        else:
            kv = k + "=" + url_encode(str(value))
            a.append(kv)
    query_str = '&'.join(a)
    return query_str


def build_canonical_uri(request: AuthRequest):
    """
    编码组装uri
    :param url:
    :return:
    """
    pattens = unquote(request.uri).split('/')
    uri = []
    for v in pattens:
        uri.append(url_encode(v))
    urlpath = "/".join(uri)
    if urlpath[-1] != '/':
        urlpath = urlpath + "/"  # always end with /
    return urlpath


def build_canonical_headers(request: AuthRequest, signed_headers: []):
    """
    编码组装headers
    :param request:
    :param signed_headers:
    :return:
    """
    a = []
    __headers = {}
    for key in request.headers:
        key_encoded = key.lower()
        value = request.headers[key]
        value_encoded = value.strip()
        __headers[key_encoded] = value_encoded
        if sys.version_info.major == 3:
            request.headers[key] = value_encoded.encode("utf-8").decode('iso-8859-1')
    for key in signed_headers:
        a.append(key + ":" + __headers[key])
    return "\n".join(a) + "\n"


def build_signed_headers(request: AuthRequest):
    """
    组装参与签名的headers，当前版本包含所有headers
    :param request:
    :return:
    """
    a = []
    for key in request.headers:
        a.append(key.lower())
    a.sort()
    return a


def find_header(r, header):
    for k in r.headers:
        if k.lower() == header.lower():
            return r.headers[k]
    return None


def build_signature(string_sign: str, signing_key: str):
    hm = hmacsha256(signing_key, string_sign)
    return binascii.hexlify(hm).decode()


def HexEncodeSHA256Hash(data):
    sha256 = hashlib.sha256()
    sha256.update(data)
    return sha256.hexdigest()


def build_authHeader_Value(signature, access_key, signed_headers):
    return "Algorithm=%s,Access=%s,SignHeaders=%s,Signature=%s" % (
        Consts.AUTH_ALGORITHM_256, access_key, ";".join(signed_headers), signature)


def url_encode(s):
    return quote(s, safe='~')

