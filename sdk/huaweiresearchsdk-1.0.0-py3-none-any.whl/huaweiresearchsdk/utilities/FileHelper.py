#! /usr/bin/env python
# -*- coding: UTF-8 -*-
import requests

from .Logger import Logger

# 屏蔽sdk调用https接口的告警错误
requests.packages.urllib3.disable_warnings()


def get_file(request_provider, url, request_header=None, timeout=None, stream: bool = False):
    """
    发起get请求
    :param request_provider
    :param url:
    :param request_header:
    :param timeout:
    :param stream:
    :return:
    """
    Logger().info("GET " + url)

    if request_header is None:
        request_header = {}

    return request_provider.get(url, headers=request_header, verify=False, timeout=timeout, stream=stream)
