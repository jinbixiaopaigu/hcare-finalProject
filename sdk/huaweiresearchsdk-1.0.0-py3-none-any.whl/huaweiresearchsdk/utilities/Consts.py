#! /usr/bin/env python
# -*- coding: UTF-8 -*-

BASIC_DATE_FORMAT = "%Y%m%dT%H%M%SZ"
RESEARCH_SDK_ALG = "x-research-sdk-alg"
# H256对应HAMC-SHA-256, H512对应HMAC-SHA-512
ALGORITHM_256 = "H256"
AUTH_ALGORITHM_256 = "HMAC-SHA-256"
ALGORITHM_512 = "H512"
AUTH_ALGORITHM_512 = "HMAC-SHA-512"
RESEARCH_SDK_TIME = "x-research-sdk-time"
HEADER_HOST = "Host"
HEADER_HTTP_HOST = "HttpHost"
RESEARCH_AUTHORIZATION = "ResearchAuthorization"
RESEARCH_SDK_CONTENT = "x-research-sdk-content"

AUTHORIZATION_ALGORITHM = "HMAC-SHA-256"

FILES_UPLOADS_PREFIX = "desensitive/"  # prefix of custom upload path