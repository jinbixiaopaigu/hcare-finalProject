#! /usr/bin/env python
# -*- coding: UTF-8 -*-
from ..config import RequestConfig
from ..config import BridgeConfig, HttpClientConfig

from ..provider import ApiClientProvider, BridgeDataProvider
from ..utilities import Utils


class BridgeClient(object):
    """
    封装了与Hiresearchcloud的交互
    """

    def __init__(self, bridgeconfig: BridgeConfig, httpclientconfig: HttpClientConfig = None, requestconfig: RequestConfig = None):
        """
        构造器
        :param bridgeconfig: bridge配置
        :param httpclientconfig: http配置
        :param requestconfig: request headers配置
        """
        Utils.assert_not_none(bridgeconfig, "bridgeconfig")

        self.__bridgeconfig = bridgeconfig
        self.__httpclientconfig = httpclientconfig
        self.__requestconfig = requestconfig

        self.__apiclient_provider = ApiClientProvider(httpclientconfig)

        self.__bridgedata_provider = BridgeDataProvider(self.__bridgeconfig, self.__httpclientconfig,
                                                        self.__apiclient_provider, self.__requestconfig)

    def get_bridgeconfig(self):
        """
        获取bridge配置
        :return:
        """
        return self.__bridgeconfig

    def get_httpclientconfig(self):
        """
        获取http配置
        :return:
        """
        return self.__httpclientconfig

    def get_requestconfig(self):
        """
        获取request config
        :return:
        """
        return self.__requestconfig

    def get_bridgedata_provider(self):
        """
        获取数据api
        :return:
        """
        return self.__bridgedata_provider
