#! /usr/bin/env python
# -*- coding: UTF-8 -*-

import json
import sys
import urllib3

from ..config import RequestConfig
from ..model.table import FilterOperatorType
from ..exceptions import ErrorCodes, CustomException
from ..utilities import Logger
from ..config import BridgeConfig, HttpClientConfig
from ..model import GetFileRequest, ListObjectRequest
from ..model.table import SearchTableDataRequest
from ..model import BatchGetFileRequest
from ..model import ObjectMeta
from ..model.result import ListObjectResponse
from ..provider import ApiClientProvider
from ..utilities import HttpHelper, Utils, Consts


class HiResearchDataService(object):
    """
    获取hiresearch数据的服务
    """

    def __init__(self, bridgeconfig: BridgeConfig, httpclientconfig: HttpClientConfig,
                 requestconfig: RequestConfig,
                 apiclientprovider: ApiClientProvider):
        self.__bridgeConfig = bridgeconfig
        self.__httpClientConfig = httpclientconfig
        self.__requestconfig = requestconfig
        self.__apiClientProvider = apiclientprovider

        self.__timeout = None
        if self.__httpClientConfig is not None:
            self.__timeout = (self.__httpClientConfig.get_connect_timeout(), self.__httpClientConfig.get_read_timeout())

    def list_projects(self):
        """
        列举用户当前已加入的项目列表
        :return:
        """
        url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(), self.__bridgeConfig.URL_PROJECT_LIST)

        request_header = {
            "User-Agent" : self.__bridgeConfig.get_useragent()
        }
        if self.__requestconfig is not None:
            if self.__requestconfig.get_headers() is not None:
                request_header = self.__requestconfig.get_headers()
                request_header["User-Agent"] = self.__bridgeConfig.get_useragent()

        result = HttpHelper.get(self.__apiClientProvider.prepare_request(),
                                self.__bridgeConfig.get_access_key(),
                                self.__bridgeConfig.get_access_secret(),
                                url, request_header,
                                timeout=self.__timeout)

        info_ret = json.loads(result, encoding="utf8")

        return info_ret

    def query_table_data(self, req: SearchTableDataRequest, callback: any):
        """
        查询研究数据表数据
        :param req:
        :param callback: 回调函数，用于处理数据行
        :return:
        """
        has_group_by_fields = False
        for filter in req.filters:
            filte_json = vars(filter)
            if filte_json['operator'] == FilterOperatorType.DISTINCT:
                has_group_by_fields = True

        url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(),
                                        self.__bridgeConfig.URL_SEARCH_TABLE_DATA)
        # 查询第一页
        request_body = Utils.dumps(req)

        request_header = {
            "Project-Id": req.project_id,
            "User-Agent": self.__bridgeConfig.get_useragent()
        }
        if self.__requestconfig is not None:
            if self.__requestconfig.get_headers() is not None:
                request_header = self.__requestconfig.get_headers()
                request_header["Project-Id"] = req.project_id
                request_header["User-Agent"] = self.__bridgeConfig.get_useragent()
        result = HttpHelper.post(self.__apiClientProvider.prepare_request(),
                                 self.__bridgeConfig.get_access_key(),
                                 self.__bridgeConfig.get_access_secret(),
                                 url,
                                 request_body,
                                 request_header,
                                 timeout=self.__timeout)

        info_ret = json.loads(result, encoding="utf8")

        # 聚合查询
        if has_group_by_fields:
            # 有分组字段
            if "aggregations" in info_ret and info_ret["aggregations"] is not None:
                callback(info_ret["aggregations"]["composite"]["results"], info_ret["total"])
            else:
                callback([], 0)
        else:
            # 非聚合查询
            if info_ret["total"] == 0:
                callback([], 0)
            else:
                if 'results' not in info_ret:
                    callback([], 0)
                else:
                    # 是否需要限制查询数据条数
                    limit_results = True if req.giveUpWhenMoreThan is not None and req.giveUpWhenMoreThan > 0 else False
                    # 已处理的数据条数
                    processed_results_cnt = 0

                    while info_ret["results"] is not None and len(info_ret["results"]) > 0 and info_ret["total"] > 0:
                        if limit_results:
                            # 已处理数据条数超出限制条数，则跳出循环
                            next_processed_results_cnt = processed_results_cnt + len(info_ret["results"])
                            if next_processed_results_cnt > req.giveUpWhenMoreThan:
                                if info_ret["scrollId"] is not None:
                                    self.cleanScroll(info_ret["scrollId"], req.project_id)
                                callback(info_ret["results"][:req.giveUpWhenMoreThan - processed_results_cnt],
                                         info_ret["total"])
                                break
                            processed_results_cnt = next_processed_results_cnt

                        # 调用用户回调函数
                        callback(info_ret["results"], info_ret["total"])

                        # 查询后续页
                        req.virtualScrollId = info_ret["scrollId"]
                        request_body = Utils.dumps(req)
                        result = HttpHelper.post(self.__apiClientProvider.prepare_request(),
                                                 self.__bridgeConfig.get_access_key(),
                                                 self.__bridgeConfig.get_access_secret(),
                                                 url,
                                                 request_body,
                                                 request_header,
                                                 timeout=self.__timeout)

                        info_ret = json.loads(result, encoding="utf8")

                        if 'results' not in info_ret:
                            break


    def batch_download_file(self, req: BatchGetFileRequest):
        """
        批量下载file
        :return:
        """
        url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(), self.__bridgeConfig.URL_FILE_DOWNLOAD)
        request_body = req.get_file_paths()
        request_header = {
            "Project-Id": req.get_project_id(),
            "User-Agent": self.__bridgeConfig.get_useragent()
        }
        if self.__requestconfig is not None:
            if self.__requestconfig.get_headers() is not None:
                request_header = self.__requestconfig.get_headers()
                request_header["Project-Id"] = req.get_project_id()
                request_header["User-Agent"] = self.__bridgeConfig.get_useragent()
        result = HttpHelper.post(self.__apiClientProvider.prepare_request(),
                                 self.__bridgeConfig.get_access_key(),
                                 self.__bridgeConfig.get_access_secret(),
                                 url,
                                 request_body,
                                 request_header,
                                 timeout=self.__timeout)

        info_ret = json.loads(result, encoding="utf8")

        print('file path list : ' + json.dumps(info_ret))
        try:
            # 循环下载文件
            for item in info_ret:
                path_url = item['url']
                # 指定了下载目录，启用流式下载
                httpPool = urllib3.PoolManager()
                # httpsPool = urllib3.ProxyManager("http://proxy.huawei.com:8080/")
                res = httpPool.request("GET", path_url)
                filename = item['key'].split('/')
                name_num = len(filename) - 1
                if req.get_output_path().endswith("/"):
                    local_filename = req.get_output_path() + filename[name_num]
                else:
                    local_filename = req.get_output_path() + "/" + filename[name_num]
                with open(local_filename, 'wb') as out_file:
                    out_file.write(res.data)
                res.release_conn()
        except Exception as err:
            Logger().error("Failed to download file，" + ErrorCodes.get_err_msg(err))
            raise CustomException(ErrorCodes.ERR_CODE_CLOUD_ERROR, "Failed to download file").with_traceback(
                sys.exc_info()[2])


    def list_objects(self, req: ListObjectRequest):
        """
        列举指定目录下的文件、目录
        :return:
        """
        url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(), self.__bridgeConfig.URL_FILE_LIST)

        request_body = {
            'nextMarker': req.get_marker(),
            'maxKeys': req.get_max_keys(),
            'prefix': req.get_prefix()
        }
        request_header = {
            "Project-Id": req.get_project_id(),
            "User-Agent": self.__bridgeConfig.get_useragent()
        }
        if self.__requestconfig is not None:
            if self.__requestconfig.get_headers() is not None:
                request_header = self.__requestconfig.get_headers()
                request_header["Project-Id"] = req.get_project_id()
                request_header["User-Agent"] = self.__bridgeConfig.get_useragent()
        result = HttpHelper.post(self.__apiClientProvider.prepare_request(),
                                 self.__bridgeConfig.get_access_key(),
                                 self.__bridgeConfig.get_access_secret(),
                                 url,
                                 request_body,
                                 request_header,
                                 timeout=self.__timeout)

        info_ret = json.loads(result, encoding="utf8")

        if 'contents' not in info_ret and info_ret['contents'] is None:
            return ListObjectResponse([],'')

        global next_marker
        if "nextMarker" in info_ret:
            next_marker = info_ret["nextMarker"]
        object_metas = []
        for ret_object in info_ret["contents"]:
            if ret_object["key"] == Consts.FILES_UPLOADS_PREFIX or ret_object["key"] == Consts.FILES_UPLOADS_PREFIX + req.get_prefix():
                continue

            object_meta = ObjectMeta(ret_object["key"],
                                     ret_object["key"][len(ret_object["key"]) - 1] == "/",
                                     ret_object["size"])
            object_metas.append(object_meta)
        return ListObjectResponse(object_metas, next_marker, info_ret['truncated'])

    def cleanScroll(self, scrollId:str, project_id:str):
        """
        手动清除scroll id
        """
        print('clear scroll start')
        request_header = {
            "Project-Id": project_id,
            "User-Agent": self.__bridgeConfig.get_useragent()
        }
        url = HttpHelper.build_http_url(self.__bridgeConfig.get_baseurl(), self.__bridgeConfig.URL_CLEAN_SCROLL)
        request_body = {
            'virtualScrollId': scrollId
        }
        result = HttpHelper.post(self.__apiClientProvider.prepare_request(),
                                 self.__bridgeConfig.get_access_key(),
                                 self.__bridgeConfig.get_access_secret(),
                                 url,
                                 request_body,
                                 request_header,
                                 timeout=self.__timeout)
        if result:
            print('clear scroll success.')
        else:
            print('clear scroll failed.')

